package com;

public class MainDev2 {


	void printOutput()
	{
		System.out.println("Thank you for attending the session!!");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//object creation
		//ClassName referenceVariableName=new ClassName();
		//new : dynamic memory allocator
		MainDev2 mainDev=new MainDev2();//object 
		mainDev.printOutput();
	}
	

}
