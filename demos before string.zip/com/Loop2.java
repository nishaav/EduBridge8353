package com;

public class Loop2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for(int i=1;i<=5;i++)
			 {
			 	for(int j=1;j<=i;j++)
			 	{
			 		System.out.print(i+" ");
			 	}
			 	System.out.println();
			 }
		
	}

}
/*
 * i=1
 *  j=1 
 *  j->1->2
 * 
 * i=2
 *  j=1
 *  j=1->2->3
 * 1 
 * 2 2  
 * 3 3 3 
 * 4 4 4 4
 * 5 5 5 5 5
 * 
 * 
 * 
 * 5 4 3 2 1
 * 4 3 2 1
 * 3 2 1
 * 2 1
 * 1							for(i=5;i>=1;i--)
 * 									for(j=i;j>=1;j--)
 * 
 * 
 * 5 4 3 2 1 
 * 5 4 3 2
 * 5 4 3							for(i=1;i<=5;i++)
 * 5 4									for(j=5;j>=i;j--)							
 * 5 
 * 
 * 
 * 
 * 
 *  1  
 *  2 1
 *  3 2 1
 *  4 3 2 1
 *  5 4 3 2 1 
 * 
 * 
 * 						for(i=1;i<=5;i++)
 * 							for(j=i;j>=1;j--)
 *
 * 
 * first column : guides about the initialization of inner loop
 * last column : guides about the termination of inner loop
 * intermediate values : guides about increment/decrement in inner loop
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 *1
 *1 2
 *1 2 3 
 *1 2 3 4 
 *1 2 3 4 5 
 *
 *
 *for(int i=1;i<=5;i++)
 *{
 *	for(int j=1;j<=5;j++)
 *	{
 *	}
 *
 */


