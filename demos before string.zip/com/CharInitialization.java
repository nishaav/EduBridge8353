package com;

import java.util.Scanner;
public class CharInitialization {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);//user interaction
		System.out.println("Please provide a character : ");
		String str=scanner.next();//initializing our variable str by user
		char ch=str.charAt(0);//initializing char variable
		System.out.println("Value of str : "+str);
		
		System.out.println("The character received is "+ch);
		//Java
	
	}

}
