package com;

public class LoopEx2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			for(int i=1;i<=3;i++)
			{
				for(int s=2;s>=i;s--)
				{	
					System.out.print(" ");
				}
				for(int j=1;j<=2*i-1;j++)
				{
					System.out.print(j);
				}
				System.out.println();
			}
			
			
			
			
			
		
		
	}

}

/*
 * 
 * i=1
 * s=2 i=1 
 * s=1 
 * s=0
 * j=1  j<=1
 * j<=2*i-1
 * j=2  2<=1
 * 
 * 
 * i=2  
 * 
 * 2*i-1  =>2*2-1=3
 * 2*1-1 2-1=1
 * 
 *     1
 *   1 2 3
 * 1 2 3 4 5
 * 
 *  1->row
 *  2->spaces
 *  3->column generating numbers 
 * 
 *
 */

