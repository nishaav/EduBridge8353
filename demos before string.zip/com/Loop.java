package com;

public class Loop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//
		for(int i=5;i>=1;--i)
		{
			System.out.println("Hello "+i);
		}
		//how to detect errors in loop
		// No output
		//-> mistake while designing the conditions
		
		// infinite output
		//->mistake while specifying increment/decrement
		
		int j=1;
		while(j<=10)
		{
			System.out.println("Welcome "+j);
			++j;
		}
		
		
		int k=1;
		do
		{
			System.out.println("End of Program"+k);
			++k;//1-->2	
		}while(k>=5);
		
		
		
		
		
		
		
		//1) initial point
		//2) condition
		//3) statement
		//4) in/de 
		//5) condition
		//6) statement
		
		
	}

}
//Assignment on if logic
/*
 * Looping
 * process of repetition
 * 
 * Loops : concept or construct
 * 
 * repetitive execution of a block of code
 * Iteration : referring each repetition
 * 
 * 
 * Entry Control Loop :
 * 
 * validation of condition takes place at the beginning
 * 
 * -> for
 * ->while
 * 
 * Exit Control Loop : 
 * validation of condition takes place at the ending 
 * -> do-while
 * 
 * 
 * 
 * three parameters to be specified : 
 * 1) initial point : 
 * 2) terminating point : 
 * 3) increment/decrement point :unary operator
 * 
 *  
 *  
 *  syntax :
 *  for
 *  
 *  for(initial_point;terminating_point(condition),in/de)
 *  {
 *  	block of code	
 *  }
 * 
 *	initial_point
 *  while(condition)
 *  {
 *  	block of code
 *  	in/de;
 *  }
 *
 * 
 * 	initial point
 *  //incase condition is not getting satisfied, once the do-while loop will surely execute.
 *  do
 *  {
 *		block of code
 *  	in/de;  
 *  }while(condition);
 *
 */