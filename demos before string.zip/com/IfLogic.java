package com;
import java.util.Scanner;
public class IfLogic {

	public static void main(String[] args) {
//new : dynamic memory
		Scanner scanner=new Scanner(System.in);//input stream
		//inputs
		//Nisha
		
		System.out.println("Please enter your name : ");
		String name=scanner.nextLine();
		System.out.println("Please enter your total aggregate (10+2) : ");
		float percentage=scanner.nextFloat();
		
		if((percentage>=85) &&(percentage<=100))
		{
			System.out.println("Eligible for enrolment");
			System.out.println("Course available are  : \n1)Maths(H) \t\t\t\t 2)B.tech in CS");
			System.out.println("Please provide the course selected. \nPress '1' for Maths(H) \t Press '2' for B.tech in CS");
			int ch=scanner.nextInt();
			switch(ch)
			{
			case 1: System.out.println("Enter marks for mathematics");
					int maths=scanner.nextInt();
					if((maths>=95)&&(maths<=100))
					{
						System.out.println("Eligible for enrolment in Maths(H)");
					}
					else
					{
						System.out.println("Not Eligible for enrolment in Maths(H)");
					}
					break;
			case 2: System.out.println("Enter marks for Computer Science");
					int cs=scanner.nextInt();
					if((cs>=90)&&(cs<=100))
					{
						System.out.println("Eligible for enrolment in B.tech in CS");
					}
					else
					{
						System.out.println("Not Eligible for enrolment in B.tech in CS");
					}
			
					break;//jump statement
			default: System.out.println("Invalid input. Please check once again!");//same as else
			
			}
		}
		else if((percentage<85)&&(percentage>0))
		{
			System.out.println("Not Eligible");
		}
		else
		{
			System.out.println("Invalid input for the percentage");
		}
	
	}

}
// WAP to check whether the input provided by user is a character or not.
//if yes, check whether it is vowel or consonant
//solve using 1) if logic 2) switch 
//
/*
 * Question :
 * University Enrolment System 
 * 
 *  1)Name
 *  2)total aggregate
 *  85+
 *  ->choice of course 
 *  	-> Maths(H)
 *  		-> marks scored 10+2:
 *  				->95+
 * 		-> B.Tech in CS
 * 			-> aggregate : PCM
 * 			-> 90+		 
 * 
 * 
 * 
 * 
 */
//nested if : if inside another if
	//in case we have to interact with user
		//or
		//on the satisfaction of one condition, ither conditions 
		//has to be checked.
		
		//ATM :
		//swipe your card
		//pin number
		//options to select
		//amount 
		//amount verification
		//withdrawal takes place
		
		/*
		 * if-else- if ladder
		 * grading scale
		 * 
		 * 85+ A
		 * 70+ B
		 * 55+ C
		 * 40+ D
		 * below 40 E
		 * 
		 * where there is one possibility when multiple conditions will be checked
		 * if-else if ladder
		 * 
		 * question to be solved when we are working with ranges
		 * if logic
		 * 
		 * 
		 * 
		 * 
		 * switch case : 
		 * reduces the complexity
		 * by implementing the options and its mapping cases
		 * 1- English
		 * 2- Hindi
		 * 3- Tamil
		 * 
		 *  + 
		 *  -
		 *  *
		 *  %
		 *  
		 */