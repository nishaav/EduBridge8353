package com;

import java.util.Scanner;

public class Array {

	public static void main(String[] args) {

		
		//Best case= found at the starting
		// Average= found the element is around middle of the collection
		// Worst case : not found the element or found at last index
		// TODO Auto-generated method stub
//Linear Search : method through which we can search the existence of an element
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("Enter size of array  : ");
		int size=scanner.nextInt();
		System.out.println("Enter "+size+" elements : ");
		int ar[]=new int[size];
		for(int i=0;i<=ar.length-1;i++)
		{
			ar[i]=scanner.nextInt();	
		}
		
		System.out.println("Enter the element to searched  : ");
		int num=scanner.nextInt();
		
		int position=0;
		for(int i=0;i<ar.length;i++)
		{
			if(ar[i]==num)
			{
				position=i+1;
				break;//jump statement
			}
		}
		
		if(position>0)
		{
			System.out.println("Element "+num+" found at "+position+" position");	
		}
		else
		{
			System.out.println("Element is not found");			
		}
			
	}
	//
// WAP to find the highest element from 2-D array :	
}