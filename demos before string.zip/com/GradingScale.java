package com;

import java.util.Scanner;
public class GradingScale {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int eng,hnd,maths,sci,eco;
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the marks of 5 subjects : ");
		System.out.print("English : ");
		eng=scanner.nextInt();
		System.out.print("Hindi : ");
		hnd=scanner.nextInt();
		System.out.print("Maths : ");
		maths=scanner.nextInt();
		System.out.print("Science : ");
		sci=scanner.nextInt();
		System.out.print("Economics : ");
		eco=scanner.nextInt();
		int total=eng+hnd+maths+sci+eco;
		float percentage=total/5;
		System.out.println("Percentage scored : "+percentage);
		if((percentage>=60)&&(percentage<=100))
		{
			System.out.println("First Division");	
		}
		else if((percentage>=50)&&(percentage<60))
		{
			System.out.println("Second Division");	
		}
		else if((percentage>=40)&&(percentage<50))
		{
			System.out.println("Third Division");	
		}
		else if((percentage>=0)&&(percentage<40))
		{
			System.out.println("Fail");	
		}
		else
		{
			System.out.println("Invalid input");
		}
		
		
	}

}
