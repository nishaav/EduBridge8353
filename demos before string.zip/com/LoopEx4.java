package com;

public class LoopEx4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		/*
		 *       A
		 *    A  B  A
		 * A  B  C  B  A
		 *    A  B  A
		 *       A
		 *       
		 */
		for(int i=1;i<=3;i++)
		{
			for(int s=2;s>=i;s--)
			{
				System.out.print(" ");
			}
			for(int k=1;k<=i;k++)
			{
				
				System.out.print((char)(k+64));
			}
			for(int j=i-1;j>=1;j--)
			{
				System.out.print((char)(j+64));
			}
			
			
			System.out.println();
			
		}
		for(int i=2;i>=1;i--)
		{
			for(int s=2;s>=i;s--)
			{
				System.out.print(" ");
			}
			for(int k=1;k<=i;k++)
			{
				
				System.out.print((char)(k+64));
			}
			for(int j=i-1;j>=1;j--)
			{
				System.out.print((char)(j+64));
			}
			
			
			System.out.println();
			
		}
	}
}
/*
 * 
 * 
 *       A
 *     A * A
 *   A * * * A
 *     A * A
 *       A   
 * 
 * 
 */


