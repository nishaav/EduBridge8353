package com;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//public : access modifier
		//static : no need of an object to call the method
		System.out.println("Hello World!!");
		//System : class
		//out : instance/object
		//println() : method
		//System.out.println() : print the outputs.
	}
}
//class name
class Student
{// starting braces : start of the structure
	//properties/fields/attributes
	//variable
	String name;//
	String email;
	String contact;
	int rollNo;
	String dob;
	int age;//numeric data
	String institution;//alphabetical data
	//behavior
	//studying
	//givingexam
	//communicating their own details
	//method
	void showInformation()
	{//starting braces
		System.out.println(name+" "+email+" "+contact+" "+rollNo+" "+dob+" "+age+" "+institution);
	}//closing braces
	
}//closing braces : to mark the end of the structure


/*
 * class naming convention:
 * ->Upper Camel Case
 * student : Student
 * 
 * mobile devices : MobileDevices
 * ->class name cannot have spaces
 * ->class name cannot have special character
 * ->class name cannot begin with digits (0-9)
 *
 *
 * variable : temporary memory area of RAM which is used to hold the values provided.
 * 
 * datatype name;
 * 
 *
 * variable name : lower camel case:
 * rollNo
 * studentName
 * studentId
 * studentAge
 * 
 * 
 * methods :
 * functionality
 * 
 * datatype name
 * 
 * returntype name()//parenthesis
 * 
 * int add()
 * {
 * 	//addition
 * }
 * 
 * 
 * 
 */


/*
 *Human being class
 *animal : class
 *fruit : class
 *furniture : class
 *electronic devices : class
 laptop,mobile
 
 
 laptop : class
 hp , dell, macbook, acer,azus,.....
 
 
 
 class : a group of objects which have a common properties.
 Blueprint of an object
 it is not physical
 
 
 Student
 
 name, id,qualification, hobbies, contact_no,email, dob, age
 
 
 class in java can have
-> properties/fields/attribute
-> method
 
 
 object :
 instance/entity of a class on which basis objects are getting created. 
 
 representative
 
 Object characteristics
 ->State : represents the data hold by the instance
 ->Behavior : functionality which an object can performs
 ->identity : id allocated to instances by the JVM to make it uniquely identifiable
 
 Sriram : Name, contact,email,dob,age
 
 
 Method/Function : executable block of code which is defining the behavior of the class
 
 
 
 *
 *
 *
 * 
 * class :
 * 
 * object :
 * 
 * method/function :
 * 
 * 
 */
