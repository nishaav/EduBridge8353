package com;

public class NestedLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		for(int i=1;i<=2;i++)//outer
		{
			for(int j=1;j<=2;j++)//inner
			{
				System.out.println("i:"+i+" j:"+j);//total number of times : 100
			}
		}
	}
}
/*
 * 
 * i:1
 * j:1
 * 							i:1 j:1
							i:1 j:2
 * j:2
 * j:3
 * 
 * i:2
 * j:1						i:2 j:1
 * j:2						i:2 j:2
 * 
 * j:3
 * i:3
 * 
 * 
 * 
 */
