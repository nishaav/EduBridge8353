package com;

public class MainDev1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			show();//;terminator: end of line (;)
			int result=getValue();
			String course=getCourseName();
			int output=add(23,45);
			//concatenation : joining the strings and making one bigger string
			System.out.println(result);
			System.out.println(course);
			System.out.println("the output of addition is "+add(23,45));
			
			System.out.println("the output of addition is "+output);
			//the output of addition is <output>
	}
	
	//non parameterised
	//user defined method creation
	static void show()
	{//starting braces
		System.out.println("Hello Learner");
		System.out.println("Welcome to the java programming");
	}//ending braces
	
	static int getValue()
	{
		return 999;
	}
	static String getCourseName()
	{
		return "Fullstack Java Programming";
	}
	//parameterized method
	static int add(int num1,int num2)//parameters/arguments
	{
		return num1+num2;
	}
	
	
	
}
