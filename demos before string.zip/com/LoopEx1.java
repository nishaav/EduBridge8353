package com;

public class LoopEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//rows
		for(int i=1;i<=5;i++)
		{
			//space loop
			for(int k=5;k>i;k--)
			{
				System.out.print(" ");
			}
			//column
			for(int j=1;j<=i;j++)
			{
				System.out.print(j+" ");
			}
			System.out.println();
		}
		
		/*
		 * i=1
		 *   k=5  k>i  5>1
		 *   k=4  4>1  
		 *   k=3  3>1
		 *   k=2  2>1
		 *   k=1  1>1
		 *   
		 *   j=1  j<=i  1<=1
		 *   j=2  2<=1
		 * 
		 * i=2  
		 * 	k=5 k>i  5>2
		 *  k=4 4>2
		 *  k=3 3>2
		 *  k=2 2>2
		 *  
		 *  j=1 j<=i 1<=2
		 *  j=2 2<=2
		 *  j=3 3<=2
		 * 
		 *  
		 *  5 4 3 2 1
		 *  5 4 3 2
		 *  5 4 3
		 *  5 4
		 *  5
		 *  
		 *  			for(i=1;i<=5;i++)
		 *  				for(j=5;j>=i;j--)
		 *  					S.O.P(j);
		 *  
		 *  
		 *  55555
		 *  4444
		 *  333
		 *  22
		 *  1
		 *  
		 *  
		 *  
		 *  
		 *  
		 */
		
	}

}
