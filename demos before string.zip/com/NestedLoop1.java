package com;

public class NestedLoop1 {

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		int i,j;//local variable
//		for(i=1;i<=5;i+=2)
//		{
//			System.out.println("Iteration, i : "+i);
//			for(j=1;j<=5;j++)//inner loop
//			{
//				System.out.println(" j : "+j);
//			}
//			System.out.println("Ending value of j : "+j);
//		}
//		System.out.println("Ending value of i : "+i);
//	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j;
		System.out.println("Iteration in Reverse Order : ");
		
		for(i=5;i>=1;i--)
		{
			System.out.println("  i: "+i);
			
			for(j=1;j<=i;j++)
			{
				System.out.println("j: "+j);
			}
		}
		System.out.println("End of program on i as "+i);

	}

	
	

}
/*
 * i:1							O/P Iteration, i:1
 * 												j:1	
 *    j:1										j:2
 *    j:2										j:3
 *    j:3										j:4					
 *    j:4										j:5
 *    j:5							Ending value of j : 5/6
 *    j:6
 *    
 *    
 * 
 *    
 *    O/P : 
 *    Iteration in reverse order :
 *    i:5
 *     j:1
 *     j:2
 *     j:3
 *     j:4
 *     j:5
 *    i:4
 *     j:1
 *     j:2
 *     j:3
 *     j:4
 *    i:3
 *     j:1
 *     j:2
 *     j:3
 *    i:2
 *     j:1
 *     j:2
 *    i:1
 *     j:1
 *    End of Program on i as 0 
 *     
 *     
 *    
 *    
 *    
 *    
 *    
 *    
 *
 *
 */

