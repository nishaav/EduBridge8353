package com;

public class Main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		show();
		int num1=34,num2=89;
		int num3=75,num4=25;
		Main1 main1=new Main1();//instance or object of the class
		int result=main1.add(num1,num2);
		System.out.println(result);
		StudentDetails.display();//class reference
		StudentDetails studentDetails=new StudentDetails();
		int output=studentDetails.addition(num3, num4);
		System.out.println(output);
		
	}
/*
 * public : access modifier which makes main method accessible everywhere.
 * static : keyword which avoid object creation
 * void : return type void : nothing would be returned
 * System.out.println();
 * System.out.print();
 * main : method name
 * starting point of execution  
 */
	static void show()
	{
		System.out.println("Welcome To EduBridge");
	}
	//parameterised method
	int add(int a,int b)
	{
		System.out.println("Calling Add method");
		return a+b;
	}
}

class StudentDetails
{
	static void display()
	{
		System.out.println("Welcome To EduBridge Learning");
	}
	//parameterised method
	int addition(int a,int b)
	{
		System.out.println("Calling Addition Method For Class StudentDetails");
		return a+b;
	}
}

//github account
//github.com






