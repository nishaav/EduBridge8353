package com;
import java.util.Scanner;

public class Question1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// WAP to check whether the input provided by user is a character or not.
		//if yes, check whether it is vowel or consonant
		//solve using 1) if logic 2) switch 
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter a character : ");
		String str=scanner.next();
		char ch=str.charAt(0);
		//char ch=scanner.next().charAt(0);
		
		if((ch>='a' && ch<='z') || (ch>='A' && ch<='Z'))
		{
			System.out.println("Character found");
			switch(ch)
			{
				case 'A':
				case 'E':
				case 'I':
				case 'O':
				case 'U':
				case 'a':
				case 'e':
				case 'i':
				case 'o':
				case 'u':System.out.println(ch+" is a vowel");
					break;
				default:System.out.println(ch+" is a consonant");	
			}
		}
		else
		{
			System.out.println("Not a character");
		}
	}
}
