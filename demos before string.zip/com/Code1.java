package com;

import java.util.Scanner;

public class Code1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter your age : ");
		int age=scanner.nextInt();
		//if(condition)
		//decision making 1
		//control flow
		if(age>=18)
		{
			System.out.println("You are eligible for voting");
			//statement will execute when condition satisfies
		}
		else
		{
			System.out.println("You are not eligible for voting");
			
			//statement will execute when condition is not satisfied
		}
		
	}

}
