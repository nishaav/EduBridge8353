package com;

import java.util.Scanner;

public class UserInteraction1 
{
	static String courseName;//
	String studentName;//member variable/instance/non-static 
	public static void main(String[] args) 
	{
		String name;
		int id;
		Scanner scanner=new Scanner(System.in);//scanner class instance creation
		System.out.println("Enter your name : ");
		name=scanner.nextLine();
		//System.out.println("Enter your id : ");
	//	id=scanner.nextInt();
		System.out.println("Welcome "+name);
		UserInteraction1 user=new UserInteraction1();
		System.out.println(user.studentName);
	}
	void declare()
	{
		
		//System.out.println(name);
		System.out.println(studentName);
	}
	void define()
	{
		//System.out.println(name);
		System.out.println(studentName);
	}
	
}
/* Types of Variable : 
 * datatype variableName;
 * 
 * 3 types of variables in java :
 * 1) local variable : variables declared/created inside a method. They have a scope of within the 
 * 						method.
 * 2) non-static/instance/member variable : variables declared/created inside a class. They have a scope of within the 
 * 						class.
 * 3) static variable : variable with a static keyword
 *
 *
 *
 *
 */

