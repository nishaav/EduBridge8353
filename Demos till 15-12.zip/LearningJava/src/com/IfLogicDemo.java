package com;

import java.util.Scanner;

public class IfLogicDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter a number : ");
		int num1=scanner.nextInt();
		if((num1%2==0) && (num1%3==0))
		{
			System.out.println("Divisible by 2 and 3 ");
		}
		else
		{
			System.out.println("Not divisible by 2 and 3  ");	
		}
		
		//		float per=scanner.nextFloat();
//		System.out.println("Enter the average of PCM : ");
//		float avg=scanner.nextFloat();
//		
//		if((per>=85)||(avg>=90))
//		{
//			System.out.println("Eligible for admission");
//		}
//		else
//		{
//			System.out.println("Not eligible for admission");
//		}
//		
		
	//WAP to check the number input by user is even or odd
		//10%2==0 even
		//11%2=1 odd
		//2 4 6 8 10 12 14 16 18 20 
		
	//WAP to check whether the number provided by user is divisible by 2 and 3 or not.	
		
		
	}

}
