package com;

public class MainDev 
{//starting
	
//	String name;
//[]: bracket : to hold multiple data
	public static void main(String[] args) {
		
//	comments	System.out.println("Hello User");//output statement
	System.out.println("Welcome to java programming sessions");
		// TODO Auto-generated method stub

		System.out.println("*\n**\n*** ");
//\n: escape character
		
	// : single line comment	

		
		/*starting
		 code statement
		 
		 
		 */
		
		/* multi line comment */ 
	}
}//ending
/* public : access modifier 
 * class : keyword
 * static : keyword
 * void : return type
 * main : method name
 * String : class
 * args : variable
 * System : class
 * out : instance/object
 * println() : method 
 * 
 *
 *      *
 *      * *
 *      * * *
 *      single SOP statement
 * 
*/
