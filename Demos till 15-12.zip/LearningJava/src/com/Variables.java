	package com;

public class Variables {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Learner learner=new Learner();
		learner.studentName="Aniket";
		learner.courseName="Fullstack Java Program";
		
		Learner learner1=new Learner();
		learner1.studentName="Nagma";
		System.out.println(learner.studentName);//Aniket
		System.out.println(learner.courseName);//Fullstack
		
		System.out.println(learner1.studentName);//Nagma
		System.out.println(learner1.courseName);//Fullstack
		
		learner1.courseName="Capgemini Certified Fullstack Java Program";
		
		System.out.println(learner.studentName);//Aniket
		System.out.println(learner.courseName);//Fullstack
		
		System.out.println(learner1.studentName);//Nagma
		System.out.println(learner1.courseName);//not o/p
		
	}

}
class Learner
{
	String studentName;
	static String courseName;
}

