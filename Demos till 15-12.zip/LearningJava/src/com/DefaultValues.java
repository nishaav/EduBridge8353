package com;

public class DefaultValues {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			DefaultValue defaultValue=new DefaultValue();
			System.out.println("int : ["+defaultValue.num1+"]");
			System.out.println("byte : ["+defaultValue.b+"]");
			System.out.println("char : ["+defaultValue.ch+"]");
			System.out.println("double : ["+defaultValue.d+"]");
			System.out.println("long : ["+defaultValue.data+"]");
			System.out.println("short : ["+defaultValue.dummy+"]");
			System.out.println("float : ["+defaultValue.f+"]");
			System.out.println("boolean : ["+defaultValue.status+"]");
			System.out.println("String : ["+defaultValue.name+"]");
	
	
	}

}
class DefaultValue
{
	//whenever an instance for the class is created, memory to the instance variable is allocated and
	// they are initialized by a default value
	//no concept of garbage value is applicable in java
	String name;
	int num1;
	boolean status;
	char ch;
	long data;
	short dummy;
	byte b;
	float f;
	double d;	
}
