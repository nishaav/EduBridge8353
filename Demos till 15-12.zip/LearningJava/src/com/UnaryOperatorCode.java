package com;

public class UnaryOperatorCode {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10,b=100,c=-5;
		//10+101-6-6+101+11+100-(-7)
		//10+101-12+101+11+100+7
		//301-2+19
		//320-2
		//318
		int result=(a++)+(++b)+(--c)+(c)+(b--)+a+b-(--c);
		//a=10->11
		//b=100->101->100
		//c=-5->-6->-7
		System.out.println("Value : "+result);
		
				
	}

}
