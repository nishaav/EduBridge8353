package com;

public class Operators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		int a=10;
//		//a=a+2;
//		a+=2;
//		//int b;
//		//int c=a+b;
//		System.out.println(a);
		System.out.println("Post-decrement");
		//	
		//post-increment
//		int a=10;
//		System.out.println(a);//10
//		int b=a--;
//		//a->11 b=10
//		System.out.println(a);//9
//		System.out.println(b);//10
//		System.out.println("Pre-decrement");
//		//pre-increment
//		int i=10;
//		System.out.println(i);//10
//		int j=--i;
//		//a->11 b=10
//		System.out.println(i);//9
//		System.out.println(j);//9
//		

		//binary language 0 1
		int n=5;//number which has to be shifted
		int s=5;//number of positions
		int result=n<<s;
		//     1 0 0 1 //5
		//   1 0 0 1 0 //100
		System.out.println("n : "+n);
		System.out.println("output : "+result);
		
	}
}
/*
 * Operators :
 * Operators are the symbols which helps in initialization and manipulation of the operand values.
 * variable/operand
 * 
 * 1) Assignment Operator : =
 * 2) Arithmetic Operator : +,-,/(quotient),*,%(reminder)
 * 3) Arithmetic Assignment : +=,-=,*=,/=,%=
 * 4) Unary Operator : Single Operand
 * ->Increment(increased) : ++ 
 * 		->pre-increment :++a
 * 		->post-increment : a++
 * ->Decrement(decreased) : -- 
 * 		->pre-decrement : --a
 * 		->post-decrement: a--
 * 5) Comparison Operator or Relational Operator :
 * == (exactly equals to),>=,<=,>,<,!=
 * LHS or RHS
 * 
 * 
 * 6)Logical operators : using logical operator, one can compare multiple conditions
 * && : And
 * || : Or
 * !  : Not
 * 
 *               truth table
 * C1      C2     C1&&C2      C1||C2        !C1
 * T       T        T            T          F
 * T       F        F            T          F
 * F       T        F            T          T
 * F       F        F            F          T
 * 
 * 7)Shift Operator 
 * ->left shift operator: <<
 * which can shift a number by certain positions. 
 * a<<b
 * a: integer
 * b: a non-negative integer
 * 10<<1
 * 
 * Decision Making constructs
 * we verify or check the values and on the basis of which we determine the possible output
 * 
 * 
 * checking the satisfaction of a condition
 * 
 * decision making constructs
 * 
 * 1) if-logic
 * syntax : 
 * 
 * if(condition)
 * {
 * 	//output
 * }
 * if-else
 * syntax :
 * if(condition)
 * {
 * 	statement
 * 
 * }
 * else
 * {
 * 	statement
 * }
 */ 
