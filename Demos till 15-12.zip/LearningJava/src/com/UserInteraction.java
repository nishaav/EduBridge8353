package com;

import java.util.Scanner;//import statement

public class UserInteraction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter a number : ");
		
		int a=scanner.nextInt();//RAM
		System.out.println("The value received is "+a);
		/*
		 * System.out : OutputStream
		 * RAM  		System.out		Console
		 * 				OutputStream
		 * 
		 * Console		System.in		RAM
		 * 				InputStream
		 * 
		 * 
		 * System.in : InputStream
		 * 
		 * 
		 */
	}

}

/*
 * location : java.util
 * 
 * nextInt() : initialize an int variable
 * nextLong() : initialize a long variable
 * nextFloat() : initialize a float variable
 * nextDouble() : initialize a double variable
 * next() or nextLine() : initialize a String variable
 * next() : Nisha
 * nextLine() : Nisha Jaiswal
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */
