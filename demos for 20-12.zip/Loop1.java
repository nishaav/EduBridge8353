package com;

public class Loop1 {

	public static void main(String[] args) 
	{//infinite loop
		int count=0;
		System.out.println("Odd Numbers between 1 to 20");
		for(int i=1;i<=20;i++)
		{
			if(i%2!=0)
			{
				count++;
				System.out.print(i+" ");
			}
			
		}
		System.out.println("\nThe total count of odd numbers is "+count);
		
		
		//generate even numbers between 1 to 20 and give the count of even numbers generated
		//generate odd numbers between 1 to 20 and give the count of even numbers generated
		//check whether the number input by user is prime or not
		//generate prime number between 1 to 20
	}
}
