package com.cg.hibernateDemobatch1;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cg.hibernateDemobatch1.entities.Learner;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	insertData();
    }
    static void insertData()
    {
       	//specifying information regarding the database to create a connection
  	   EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dbinfo");
  	   //access the connection
  	   EntityManager entityManager=entityManagerFactory.createEntityManager();
  	    try
        {
     	   Learner learner=new Learner();
     	   learner.setLearnerName("Jatin");
     	   learner.setLearnerEmail("jatin.tambe@ymail.com");
     	   learner.setLearnerAge(24);
     	   EntityTransaction entityTransaction=entityManager.getTransaction();
     	   entityTransaction.begin();
     	   entityManager.persist(learner);//insert query
     	   entityTransaction.commit();
     	   System.out.println("Data inserted successfully.");
     	}
        catch(Exception e)
        {
     	   e.printStackTrace();
     	   System.out.println("Unable to insert the data."); 
        }
        finally
        {
     	   entityManager.close();
      	  
        }

    }
   
    
    
    
    
    static void fetchData()
    {
      	//specifying information regarding the database to create a connection
   	   EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dbConnect");
   	   //access the connection
   	   EntityManager entityManager=entityManagerFactory.createEntityManager();
   	     try
         {
        	 Learner learner=entityManager.find(Learner.class, 1);//to fetch the data on the basis of primary key.
        	 System.out.println(learner.getLearnerName()+" "+learner.getLearnerAge()+" "+learner.getLearnerEmail());
         }
         catch(Exception e)
         {
        	 e.printStackTrace();
         }
         finally
         {
        	entityManager.close(); 
        	entityManagerFactory.close();
         }
    }
    static void updateData()
    {
    	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dbConnect");
    	   //access the connection
    	EntityManager entityManager=entityManagerFactory.createEntityManager();
    	EntityTransaction entityTransaction=entityManager.getTransaction();
    	try
        {
    		entityTransaction.begin();
    		Learner learner=entityManager.find(Learner.class, 1);//to fetch the data on the basis of primary key.
         	learner.setLearnerName("Jitesh");
         	learner.setLearnerEmail("jitesh@gmail.com");
    		entityTransaction.commit();
    		System.out.println("Updated successfully");
        }
        catch(Exception e)
        {
         	 e.printStackTrace();
        }
        finally
        {
         	entityManager.close(); 
         	entityManagerFactory.close();
        }	
    }
    static void deleteData()
    {
    	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dbConnect");
 	   //access the connection
 	EntityManager entityManager=entityManagerFactory.createEntityManager();
 	EntityTransaction entityTransaction=entityManager.getTransaction();
 	try
     {
 		entityTransaction.begin();
 		Learner learner=entityManager.find(Learner.class, 1);//to fetch the data on the basis of primary key.
      	entityManager.remove(learner);
 		entityTransaction.commit();
 		System.out.println("Delete successfully");
     }
     catch(Exception e)
     {
      	 e.printStackTrace();
     }
     finally
     {
      	entityManager.close(); 
      	entityManagerFactory.close();
     }	

    }
}
