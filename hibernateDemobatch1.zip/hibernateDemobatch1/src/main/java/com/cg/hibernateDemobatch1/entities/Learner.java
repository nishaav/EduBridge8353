package com.cg.hibernateDemobatch1.entities;

import javax.persistence.Column;
import javax.persistence.Entity;//JPA library
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity // to mark class as a table structure provider
@Table(name="learner_info")//provide table name
/*
 * 
 * 
 */
public class Learner implements java.io.Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id //primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY)//auto increment
	private int learnerId;
	@Column(name = "learner_name",nullable = false)
	private String learnerName;
	@Column(name="learner_age")
	private int learnerAge;
	@Column
	private String learnerEmail;
	public int getLearnerId() 
	{
		return learnerId;
	}
	public void setLearnerId(int learnerId) {
		this.learnerId = learnerId;
	}
	public String getLearnerName() {
		return learnerName;
	}
	public void setLearnerName(String learnerName) {
		this.learnerName = learnerName;
	}
	public int getLearnerAge() {
		return learnerAge;
	}
	public void setLearnerAge(int learnerAge) {
		this.learnerAge = learnerAge;
	}
	public String getLearnerEmail() {
		return learnerEmail;
	}
	public void setLearnerEmail(String learnerEmail) {
		this.learnerEmail = learnerEmail;
	}
	
}
//classes mapped as tables in hibernate
//variables mapped as columns in hibernate