package com;
import java.util.ArrayList;
public class DemoProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//12,23,34,54,6,67,89,2
		
		
		ArrayList<Integer> al=new ArrayList<>();
		al.add(12);
		al.add(23);
		al.add(34);
		al.add(54);
		al.add(6);
		al.add(67);
		al.add(89);
		al.add(2);
		System.out.println(al);
		al.remove(2);
		System.out.println(al);
		al.remove(Integer.valueOf(2));//Integer.valueOf(2): casting 2 as integer type of object
		System.out.println(al);
	}
}