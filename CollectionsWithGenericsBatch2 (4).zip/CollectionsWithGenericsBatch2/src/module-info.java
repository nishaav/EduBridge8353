module CollectionsWithGenericsBatch2 {
}