package com.capgemini.design_patterns;

public class Facade {//client

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Facade1 facade=new Facade1();//objects for all the subsystems
		facade.drawOfCircle();
		facade.drawOfRectangle();
		facade.drawOfSquare();
		facade.drawOfTriangle();
	}

}

interface Shape1
{
	void draw();
}
class Rectangle1 implements Shape1//Subsystems
{
	public void draw()
	{
		System.out.println("Shape is Rectangle");	
	}
}
class Triangle1 implements Shape1//Subsystems
{
	public void draw()
	{
		System.out.println("Shape is Triangle");	
	}
}
class Circle1 implements Shape1//Subsystems
{
	public void draw()
	{
		System.out.println("Shape is Circle");	
	}
}
class Square1 implements Shape1//Subsystems
{
	public void draw()
	{
		System.out.println("Shape is Square");	
	}
}


class Facade1//Main facade class through which you will be able to interact with any subsystems
{
		private Shape1 rectangle;
		private Shape1 triangle;
		private Shape1 circle;
		private Shape1 square;
		Facade1()
		{
			rectangle=new Rectangle1();
			triangle=new Triangle1();
			circle=new Circle1();
			square=new Square1();
		}
		void drawOfRectangle()
		{
			rectangle.draw();
		}
		void drawOfTriangle()
		{
			triangle.draw();
		}
		void drawOfCircle()
		{
			circle.draw();
		}
		void drawOfSquare()
		{
			square.draw();
		}
}