package com.capgemini.design_patterns;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DAOImpl {

	public static void main(String args[])
	{
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter name, contact and enrolmentNo");
		String name=scanner.nextLine();
		int contact=scanner.nextInt();
		int enrolmentNo=scanner.nextInt();
		
		StudentDetails studentDetails=new StudentDetails();
		studentDetails.setName(name);
		studentDetails.setContact(contact);
		studentDetails.setEnrolmentNo(enrolmentNo);

		StudentDetailsDaoImpl studentDetailsDaoImpl=new StudentDetailsDaoImpl();
		int i=studentDetailsDaoImpl.insertStudent(studentDetails);
		
		if(i>0)
		{
			System.out.println("Inserted Successfully");
		}
		else
		{
			System.out.println("Unable to insert the data");
		}
		
		StudentDetails student=studentDetailsDaoImpl.getStudent(78);
		System.out.println(student);
		System.out.println("All Data of Table");
		ArrayList<StudentDetails> list=new ArrayList<>();
		list.addAll(studentDetailsDaoImpl.getAllStudents());
	
		for(StudentDetails stud:list)
		{
			System.out.println(stud);
		}

		
		StudentDetails studentInfo=new StudentDetails();
		studentInfo.setName("Nishant");
		studentInfo.setContact(70652);
		studentInfo.setEnrolmentNo(78);
		int update=studentDetailsDaoImpl.updateStudent(studentInfo);
		if(update>0)
		{
			System.out.println("Record Updated Successfully");
		}
		else
		{
			System.out.println("Unable to update");
		}
		StudentDetails studentDeleteInfo=new StudentDetails();
		studentDeleteInfo.setName("Rahul");
		studentDeleteInfo.setContact(9873);
		studentDeleteInfo.setEnrolmentNo(109);
		int delete=studentDetailsDaoImpl.deleteStudent(studentDeleteInfo);
		if(delete>0)
		{
			System.out.println("Record Deleted Successfully");
		}
		else
		{
			System.out.println("Unable to delete");
		}
		
	}	
}

class StudentDetails
{
	private String name;
	private int enrolmentNo;
	private int contact;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getEnrolmentNo() {
		return enrolmentNo;
	}
	public void setEnrolmentNo(int enrolmentNo) {
		this.enrolmentNo = enrolmentNo;
	}
	public int getContact() {
		return contact;
	}
	public void setContact(int contact) {
		this.contact = contact;
	}
	public String toString()
	{
		return name+" "+enrolmentNo+" "+contact;
	}
}

interface StudentDetailsDao
{
	List<StudentDetails> getAllStudents();
	StudentDetails getStudent(int enrolmentNo);
	int updateStudent(StudentDetails student);
	int deleteStudent(StudentDetails student);
	int insertStudent(StudentDetails student);
}

class StudentDetailsDaoImpl implements StudentDetailsDao
{

	static Connection getConnection()
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/batch8353?useSSL=false&autoReconnect=true","root","root");
			return con;
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	@Override
	public List<StudentDetails> getAllStudents() {
		// TODO Auto-generated method stub
		List<StudentDetails> listOfStudents=new ArrayList<>();
		try
		{
			Connection con=getConnection();
			String query="select * from student_details";
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery(query);
			while(rs.next())
			{
				StudentDetails student=new StudentDetails();
				student.setName(rs.getString("student_name"));
				student.setContact(rs.getInt("student_contact"));
				student.setEnrolmentNo(rs.getInt("enrolment_no"));
				listOfStudents.add(student);
			}
			rs.close();
			stmt.close();
			con.close();
			return listOfStudents;
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return listOfStudents;
		}

	
	
	}

	
	
	
	@Override
	public StudentDetails getStudent(int enrolmentNo) {
		// TODO Auto-generated method stub
		
		try
		{
			Connection con=getConnection();
			String query="select * from student_details where enrolment_no="+enrolmentNo;
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery(query);
			if(rs.next())
			{
				StudentDetails student=new StudentDetails();
				student.setName(rs.getString("student_name"));
				student.setContact(rs.getInt("student_contact"));
				student.setEnrolmentNo(rs.getInt("enrolment_no"));
				rs.close();
				stmt.close();
				con.close();
				return student;
			}
			else
			{	
				rs.close();
				stmt.close();
				con.close();
				return null;
			}
					}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public int updateStudent(StudentDetails student) {
		// TODO Auto-generated method stub
		try
		{
			Connection con=getConnection();
			String query="update student_details set student_name=?,student_contact=? where enrolment_no=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, student.getName());
			ps.setInt(2, student.getContact());
			ps.setInt(3,student.getEnrolmentNo());
			int i=ps.executeUpdate();
			ps.close();
			con.close();
			return  i;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	
	}

	@Override
	public int deleteStudent(StudentDetails student) {
		// TODO Auto-generated method stub
		try
		{
			Connection con=getConnection();
			String query="delete from student_details where enrolment_no=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setInt(1, student.getEnrolmentNo());
			int i=ps.executeUpdate();
			ps.close();
			con.close();
			return  i;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return 0;
		}
		
	}

	@Override
	public int insertStudent(StudentDetails student) {
		// TODO Auto-generated method stub

		try
		{
			Connection con=getConnection();
			String query="insert into student_details(student_name,enrolment_no,student_contact) values(?,?,?)";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, student.getName());
			ps.setInt(2,student.getEnrolmentNo());
			ps.setInt(3, student.getContact());
			int i=ps.executeUpdate();
			ps.close();
			con.close();
			return  i;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return 0;
		}
		
	}
	
}
/*

DAO :Data Access Object
DAO Interface : this interface will specify all the operations to be performed on the POJO object.
Data Access Object Class : This class implements the specified interface and the class is responsible 
for getting the data from a data source(database)
Model/POJO : this class object is simple POJO class containing the set of setters and gettersto store and retreive
the data using DAO class.

*/
