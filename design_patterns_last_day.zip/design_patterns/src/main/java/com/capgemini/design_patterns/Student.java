package com.capgemini.design_patterns;

public class Student
{
	private static Student student=new Student();
	private Student()
	{
		System.out.println("Calling the constructor");	
	}
	public static Student getStudentObject()//factory method
	{
		return student;
	}
	public void getCourseInfo()
	{
		System.out.println("Full Stack Java");
	}
}