package com.capgemini.design_patterns;

import java.util.*;
public class FactoryDesignPattern {

	public static void main(String args[])
	{
		System.out.println("Enter type of customer : ");
		Scanner scanner=new Scanner(System.in);
		String type=scanner.nextLine();
		GetBillingFactory getBill=new GetBillingFactory();//factory class
		Billing bill=getBill.getBillingFactory(type);//factory method call
		System.out.println("No. of units consumed : ");
		int units=scanner.nextInt();
		bill.getRate();
		bill.calculateBill(units);
	}
}

abstract class Billing
{
	protected double rpu;
	abstract void getRate();
	public void calculateBill(int units)
	{
		System.out.println(units*rpu);
	}
}
class DomesticBill extends Billing
{
	public void getRate() {
		rpu=4;
	}
}
//Billing billing=new DomesticBill();
class CommercialBill extends Billing
{
	public void getRate() {
		rpu=6;
	}	
}
//Billing billing=new CommercialBill();
class GetBillingFactory//Factory Class
{
	public Billing getBillingFactory(String type)//factory method
	{
		if(type==null)
		{
			return null;
		}
		else if(type.equalsIgnoreCase("Domestic"))
		{
			return new DomesticBill();
		}
		else if(type.equalsIgnoreCase("Commercial"))
		{
			return new CommercialBill();
		}
		return null;
	}
}