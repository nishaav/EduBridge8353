package com.capgemini.design_patterns;

public class Behavioural {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Chain chain=new Chain();
		chain.process(new Demo(1));
		chain.process(new Demo(-78));
		chain.process(new Demo(0));
	}
}
class Chain
{
	Processor chain;	
	
	Chain()
	{
		chain=new ValueProcessor(new ValueProcessor1(new ValueProcessor2(null)));
	}
	
	void process(Demo demo)
	{
		chain.process(demo);
	}
}

abstract class Processor
{
	private Processor nextProcessor;
	public Processor(Processor nextProcessor)
	{
		this.nextProcessor=nextProcessor;
	}
	void process(Demo demo)//recursion
	{
		if(nextProcessor!=null)
		{
			nextProcessor.process(demo);
		}
	}
}
class Demo
{
	int num1;
	Demo(int num1)
	{
		this.num1=num1;
	}
	int getValue()
	{
		return num1;
	}
}

class ValueProcessor extends Processor
{

	public ValueProcessor(Processor nextProcessor) {
		super(nextProcessor);
		// TODO Auto-generated constructor stub
	}
	void process(Demo demo)
	{
		if(demo.getValue()<0)
		{
			System.out.println("Negative value");
		}
		else
		{
			super.process(demo);
		}
	}
}	

class ValueProcessor1 extends Processor
{

	public ValueProcessor1(Processor nextProcessor) {
		super(nextProcessor);
		// TODO Auto-generated constructor stub
	}
	void process(Demo demo)
	{
		if(demo.getValue()==0)
		{
			System.out.println("Neutral value");
		}
		else
		{
			super.process(demo);
		}
	}
}	
class ValueProcessor2 extends Processor
{

	public ValueProcessor2(Processor nextProcessor) {
		super(nextProcessor);
		// TODO Auto-generated constructor stub
	}
	void process(Demo demo)
	{
		if(demo.getValue()>0)
		{
			System.out.println("Positive value");
		}
		else
		{
			super.process(demo);
		}
	}
}	
/*
 *Chain of Responsibility 
 *1) achieve loose coupling where the request is passed to a chain of responsibility. 
 *2) multiple objects are working as volunteers to handle the request 
 * 
 * 
 * 
 * Steps :
 * 1)Handler interface/abstract class which is designed to handle the request.
 * 2)Concrete Handler:to specify the functionality to be proccessed
 * 3)Client: that generates the request
 */

