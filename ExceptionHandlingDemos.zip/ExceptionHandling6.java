package dummy;

public class ExceptionHandling6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str1=null;
		try
		{
			String str="java";
			System.out.println(str.charAt(4));
			System.out.println(str1.length());
		}
		//multi-catch
		catch(StringIndexOutOfBoundsException|ArithmeticException|ArrayIndexOutOfBoundsException s)//Specialized
		{
			System.out.println("Exception Caught");
			System.out.println(s);
		}
		catch(Exception e)
		{
			System.out.println("Software/Webapp is under maintenance");
			e.printStackTrace();
		}
		finally
		{//closing the resources
			System.out.println("I will execute irrespective of others.sssss");
		}
		
	}

}
