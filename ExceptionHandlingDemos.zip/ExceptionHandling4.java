package dummy;

public class ExceptionHandling4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			System.out.println("Hello");
			System.out.println(10/0);
			System.out.println("Welcome");
		}
		finally
		{
			System.out.println("Thank you");
			System.out.println("Always Executing");
		}
	}

}
/*Possible combinations :
 * try-catch
 * 
 * try-catch-finally
 * 
 * try-finally
 * 
 */
