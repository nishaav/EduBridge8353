package dummy;

import java.util.Scanner;

public class ExceptionHandling 
{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Welcome");
		Scanner scanner =new Scanner(System.in);
		System.out.println("Enter two numbers for division : ");
		int num1=scanner.nextInt();
		int num2=scanner.nextInt();
		try
		{
			System.out.println(num1/num2);
		}
		catch(Exception e)//generalized catch block
		{//Exception e=new ArithmeticException("/ by zero");
			System.out.println(e);
		}
		System.out.println("End of program!!");
	}
}
/*
 * Exception "
 * 
 * Situation or a condition that can disrupt the normal flow of program execution.
 * 1)Checked Exception : compile time : whenever our java program works with 
 * the resources that are outside the environment of java
 * 2)Unchecked Exception : runtime (because compiler cannot recognise it)
 * logical issues with your program
 * Domain Assessment--->Coding questions ()
 * HackerEarth HackerRank
 * 
 * Good quality of internet
 * swap the screens
 * Proctored 
 * Do Select Portal 
 * incognito mode
 * Read FAQs
 * Throwable : java.lang
 * ->Exception							->Error (irrecoverable) ->MemoryOutOfStack
 * 															    ->VirtualMachineError
 * -->RuntimeException
 * ---->ArithmeticException
 * ---->NullPointerException
 * ---->NumberFormatException
 * ---->IndexOutOfBoundsException
 * ------->ArrayIndexOutOfBoundsException
 * ------->StringIndexOutOfBoundsException
 * ---->InterruptedException
 * -->ClassNotFoundException
 * -->FileNotFoundException
 * -->IOException
 * -->SQLException(JDBC)
 * 
 * try
 * {
 * in which exception can be generated
 * }
 * catch(Exception e)
 * {
 * 
 * }
 * 
 * blocks :
 * try-those statements that may generate an exception.
 * catch-
 * finally-
 * 
 * 
 * keywords
 * throws- 
 * throw-
 * 1
 * 2
 * 3
 * 4
 * 5 : Invalid  : breaked --->Control --->JVM--->Default Exception Handler --
 * 6 
 * 7
 * 8
 * 9
 * 10
 *
 *
 *
 * Exception handling
 *
 * Exception : 
 * Is an abnormal condition / statement which disrupts the normal flow of program execution.
 * 
 * Collections
 * Multi threading
 * FileHandling
 * JDBC
 * StreamAPI
 * Junit and Maven
 * 
 *
 */

