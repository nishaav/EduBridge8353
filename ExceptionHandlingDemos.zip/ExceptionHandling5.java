package dummy;

public class ExceptionHandling5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//multiple catch blocks
		try
		{
			String str="java";
			System.out.println(str.charAt(4));
		}
		catch(StringIndexOutOfBoundsException s)//Specialized
		{
			System.out.println();
			System.out.println(s);
		}
		catch(ArrayIndexOutOfBoundsException s)
		{
			System.out.println(s);
		}
		catch(NumberFormatException s)
		{
			System.out.println(s);
		}
		catch(Exception e)
		{
			System.out.println("Software/Webapp is under maintenance");
			//e.printStackTrace();
		}
		finally
		{//closing the resources
			System.out.println("I will execute irrespective of others.sssss");
		}
		
	}

}
