package dummy;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
public class ExceptionHandling8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			Scanner scanner=new Scanner(System.in);
			System.out.println("Enter the age : ");
			int age=scanner.nextInt();
			EligibilityForVoting.isValid(age);
		}
		catch(Exception e)
		{
			System.out.println(e);
			System.out.println("Invalid input.Please check once again");
		}
	}
}
//throw : used to raise the exception explicitly
class EligibilityForVoting
{
	static void isValid(int age) throws ArithmeticException,FileNotFoundException,IOException
	{
		if(age>=18)
		{
			System.out.println("Eligible for voting");
		}
		else
		{
			throw new ArithmeticException("Not Eligible for Voting");
		}
	}
}
/*
 *   throw																		throws 
 *   1)used to generate the exception explicitly								1) used for exception declaration
 *   2)throw keyword can be used inside the method								2) throws keyword has to be used with the method 
 *   																			   declaration
 *   
 *   3)throw can propagate only unchecked exception								3) can declare checked and unchecked both 
 *   																				type of exceptions.
 *	 4)throw keyword should be followed by the object of 						4) throws keyword must be followed by class name to be thrown
 *      exception which has to be thrown
 *   5) throw keyword can throw only one exception at a time					5) throws can declare multiple exceptions at a time by applying a comma
 *
 *
 *
 *
 *
 *
 *
 */


