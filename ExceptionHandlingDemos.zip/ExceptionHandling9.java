package dummy;

import java.util.Scanner;

//creating own exception : Custom Exception
public class ExceptionHandling9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			
			Scanner scanner=new Scanner(System.in);
			System.out.println("Enter the age : ");
			int age=scanner.nextInt();
			InvalidAge invalidAge=new InvalidAge();
			invalidAge.validate(age);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
class CustomException extends Exception
{
	CustomException(String message)
	{
		super(message);
	}
}
/*
 * Collections
 * FileHandling
 * MultiThreading
 * DesignPatterns 
 * MySQL - JDBC
 */
class InvalidAge 
{
	void validate(int age) throws CustomException
	{

		if(age>=18)
		{
			System.out.println("Eligible for voting");
		}
		else
		{
			throw new CustomException("Invalid for voting");
		}
		
	}
}