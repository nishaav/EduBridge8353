package dummy;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class ExceptionHandling7 {

	public static void main(String[] args) throws FileNotFoundException{
		// TODO Auto-generated method stub

		try
		{
			FileInputStream fout=new FileInputStream("C:\\Users\\hp\\OneDrive\\Desktop\\dummy.txt");
		}
		catch(Exception e)
		{
			
		}
		
	}
}
/*
 * 3 blocks : try,catch,finally
 * 2 keywords : throw,throws
 *
 *
 * throws : keyword which helps in exception declaration
 *
 *Exception Declaration : which specifies that if the method is called then exception will be raised
 * try-catch
		8-15 characters
		their special character,digit and Caps and small letter
		nisha123*
			
 *
 */


