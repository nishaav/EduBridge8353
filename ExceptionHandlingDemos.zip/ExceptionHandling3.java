package dummy;

public class ExceptionHandling3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try
		{
			String str="java";
			System.out.println(str.charAt(3));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{//closing the resources
			System.out.println("I will execute irrespective of others.sssss");
		}
		
	}
}
/*
 * finally block will execute in every situation either i am getting the exception
 * or I am not getting the exception.
*/

