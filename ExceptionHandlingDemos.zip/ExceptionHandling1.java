package dummy;

public class ExceptionHandling1 {

	static String str=null;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Welcome");
		try
		{
			System.out.println(str.isEmpty());
			System.out.println(str.length());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//System.out.println(e);
			//prints the stack/details of the exception
		}
		System.out.println("End of Program!!");
	}

}
