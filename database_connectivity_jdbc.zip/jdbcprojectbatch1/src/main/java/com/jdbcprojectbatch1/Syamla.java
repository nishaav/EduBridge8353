package com.jdbcprojectbatch1;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.util.Scanner;

public class Syamla {

	public static void main(String args[])
	{
		try
		{
			//Register the driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			//Create the connection
			//3306(default),3307,3308,3309
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/restaurantmanagementsystem?useSSL=false&autoReconnect=true","root","root");
			//create the query
			Scanner scanner=new Scanner(System.in);
			System.out.println("enter details of menu");
			System.out.print("Name : ");
    		String name=scanner.nextLine();
    		System.out.print("Count : ");
    		int count=scanner.nextInt();
    		System.out.print("Cost : ");
    		int cost=scanner.nextInt();
    		//create the query
    		//insert,update,delete : PreparedStatement : interfaces as it cannot return data can only return whether query
    		//is executing or not
    		//Select : Statement interfaces
    		//can return data fetched from the table    		
    		//String query2="insert into emp values(7,'"+name+"',"+age+",'"+contact+"','"+email+"')";
    		String query="insert into Menu(itemName,itemCount,itemCost) values(?,?,?)";
    		PreparedStatement ps=con.prepareStatement(query);
    		ps.setString(1, name);
    		ps.setInt(2,count);
    		ps.setInt(3, cost);
    		System.out.print(name+count+cost);
    		//execute the query
    		
    		int count1=ps.executeUpdate();
    		
    		if(count1>0)
    		{
    			System.out.println("Data inserted successfully");
    		}
    		else
    		{
    			System.out.println("Unable to execute the query");
    		}
    		//Statement smt
    		
    		//close the connection
    		ps.close();
    		con.close();


			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
}
