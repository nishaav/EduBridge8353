package com.jdbcprojectbatch1;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.util.Scanner;
public class App 
{
    public static void main( String[] args )
    {
    	try
    	{
    		//https://www.facebook.com/contact
    		//Register the driver
    		Class.forName("com.mysql.cj.jdbc.Driver");
    		//Create the connection
    		//DriverManager.getConnection(url, username, password);
    		//3306(default),3307,3308,3309
    		//show variables where variable_name = 'port'; to check port no
    		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/batch18103?useSSL=false&autoReconnect=true","root", "root");
    		Scanner scanner=new Scanner(System.in);
    		System.out.println("Enter the details : ");
//    		System.out.print("Name : ");
//    		String name=scanner.nextLine().trim();
//    		System.out.print("Age : ");
//    		int age=scanner.nextInt();
//    		scanner.nextLine();
//    		System.out.print("Contact : ");
//    		String contact=scanner.nextLine().trim();
    		System.out.print("Old Email : ");
    		String email=scanner.nextLine().trim();
    		String selectQuery="select * from emp where email='"+email+"'";
    		Statement stmt=con.createStatement();
    		ResultSet rs=stmt.executeQuery(selectQuery);
    		if(rs.next())
    		{
    			
    		
    			System.out.print("New Email : ");
    			String newEmail=scanner.nextLine().trim();
    		//create the query
    		//insert,update,delete : PreparedStatement : interfaces as it cannot return data can only return whether query
    		//is executing or not
    		//Select : Statement interfaces
    		//can return data fetched from the table    		
    		//insert into emp(empAge,empName,empContact,email) values(?,?,?,?);
    		//String query2="insert into emp values(8,'"+name+"',"+age+",'"+contact+"','"+email+"')";
    		//System.out.println(query2);
    		String updateQuery="update emp set email=? where empId="+rs.getInt(1);
    	//	String query="insert into emp values(?,?,?,?,?)";
    		PreparedStatement ps=con.prepareStatement(updateQuery);
    		ps.setString(1,newEmail);
    		//execute the query
    		System.out.println(updateQuery);
    		int count=ps.executeUpdate();
    		System.out.println(count);
    		if(count>0)
    		{
    			System.out.println("Data updated successfully");
    		}
    		else
    		{
    			System.out.println("Unable to execute the query");
    		}
    		
    		//close the connection
    		ps.close();
    		rs.close();
    		stmt.close();
    		}
    		
    		con.close();
    		
    		}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    		System.out.println(e);
    	}
    }
}
