package com;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class FileHandling8 {

	public static void main(String[] args) {
		// Deserialization: the process of reading the state of an object from the file
		try
		{
			FileInputStream fout=new FileInputStream("C:\\Users\\hp\\OneDrive\\Desktop\\f1.txt");//object for write with append mode operation
			ObjectInputStream oos=new ObjectInputStream(fout);
			User user=(User)oos.readObject();//we are reading the data from f1.txt by ObjectInputStream instance
			System.out.println(user.name+" "+user.age);
			oos.close();
			fout.close();
		}
		catch(Exception e)
		{	
			e.printStackTrace();
		}

	}

}
