package com;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class FileHandling7 {

	public static void main(String[] args) {
		// Serialization : the process of writing the state of an object to a file
		// state of object means data of an object.
		try
		{
			User user=new User("Geetika",24);
			FileOutputStream fout=new FileOutputStream("C:\\Users\\hp\\OneDrive\\Desktop\\f1.txt");//object for write with append mode operation
			ObjectOutputStream oos=new ObjectOutputStream(fout);
			oos.writeObject(user);
			oos.close();
			fout.close();
			System.out.println("Successful");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
//Marker Interface : The interface not having any methods it holds the functionality which will be used at the time of execution.
class User implements Serializable
{
	String name;
	transient int age;// if we don't want to write the value of any specific variable, then we will make that field as transient
	//transient int age;
	User(String name,int age)
	{
		this.name=name;
		this.age=age;
	}
}



