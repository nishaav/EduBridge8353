package com.multithreading;

public class MultiThreading7 {

public static void main(String args[])
{
	DummyThread1 dummyThread=new DummyThread1();
	Thread1 tc1=new Thread1(dummyThread);
	Thread2 tc2=new Thread2(dummyThread);
	tc1.start();
	tc2.start();
		
}
	
}
//Resource
class DummyThread1 
{
	DummyThread1()
	{
		System.out.println("Dummy Threaf Of The Class");
	}
	//synchronized with a method
	 void showSample(int value)
	{
	synchronized(this)
		{
		for(int i=1;i<=10;i++)
		{
			System.out.println(Thread.currentThread().getName()+" : "+i*value);
			try
			{
				Thread.sleep(2000);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		}
	for(int i=1;i<=10;i++)
	{
		System.out.println(Thread.currentThread().getName()+" : "+i*value+" : calling");
		try
		{
			Thread.sleep(2000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	}	
}
//Thread 1
class Thread1 extends Thread
{
	DummyThread1 dt;
	Thread1(DummyThread1 dt)
	{
		this.dt=dt;
	}
	
	public void run()
	{
		dt.showSample(4);
	}
		
}
class Thread2 extends Thread
{
	DummyThread1 dt;
	Thread2(DummyThread1 dt)
	{
		this.dt=dt;
	}
	
	public void run()
	{
		dt.showSample(12);
	}
		
}