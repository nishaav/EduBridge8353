package com.multithreading;

public class MultiThreading1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyThread myThread=new MyThread();//NEW STATE
		System.out.println(myThread.getId());
		System.out.println(myThread.getName());
		System.out.println(myThread.getPriority());
		System.out.println(myThread.getState());
		myThread.start();//PUSH THE THREAD TOWARDS JVM TO GET ALLOTED WITH THE PRIORITY 1-10
	//	myThread.start();
		System.out.println(myThread.getState());
		
	}

}
class MyThread extends Thread//(java.lang)
{
	public void run()
	{
		for(int i=1;i<=5;i++)
		{
			System.out.println("i : "+i);
			try
			{
				Thread.sleep(2000);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
	}
}