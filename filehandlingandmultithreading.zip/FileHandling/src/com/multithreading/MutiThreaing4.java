package com.multithreading;

public class MutiThreaing4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo1 demo1=new Demo1();
		Demo2 demo2=new Demo2();
		
		demo1.start();
		
		try
		{
			demo1.join();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		// join method : wait till the time another thread has not completed its working
		demo2.start();
	}

}
class Demo1 extends Thread//(java.lang)
{
	public void run()
	{
		for(int i=1;i<=5;i++)
		{
			Thread t1=Thread.currentThread();
			System.out.print(t1.getName());			
			System.out.println("i : "+i);
			try
			{
				Thread.sleep(2000);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
	}
}
class Demo2 extends Thread//(java.lang)
{
	public void run()
	{
		for(int i=1;i<=5;i++)
		{
			Thread t1=Thread.currentThread();
			System.out.print(t1.getName());
			System.out.println("i : "+i);
			try
			{
				Thread.sleep(2000);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
	}
}