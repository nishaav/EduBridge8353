package com.multithreading;

public class MultiThreading10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account account=new Account();
				
		Thread t1=new Thread(){
			
			public void run() {
				account.withdraw(35000);
			}
			
		};
		
		Thread t2=new Thread() {
			
			public void run()
			{
				account.deposit(20000);
			}
		};
		
		t1.start();
		t2.start();
		
	}

}


class Account
{
	int maxCreditAvailable=25000;
	
	synchronized void deposit(int amount)
	{
		System.out.println("Depositing the amount");
		maxCreditAvailable+=amount;
		//maxCreditAvailable=maxCreditAvailable+amount;
		System.out.println("Deposit completed");//450000
		notify();//Object class
	}
	synchronized void withdraw(int amount)
	{
		System.out.println("Withdrawing");
		if(maxCreditAvailable<amount)
		{
			System.out.println("Less balance in the account. Please add funds to withdraw");
			
			try
			{
				wait();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		maxCreditAvailable-=amount;
		System.out.println("Withdrawal completed");
	}
}

/*
 * 
 * Inter-Thread Communication :
 * 
 * 
 * 1) wait : forces the thread to release the occupied resource and wait till the time the resource
 * is not available back.
 * 2) notify : method is used to reactivate the thread at waiting state.It will activate anyone/last thread waiting in the queue.
 * 3) notifyAll :  method is used to reactivate all the thread at waiting state. 
 * 
 * 
 * 
 * 
 */
