package com.multithreading;

public class MultiThreading8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DemoThread demoThread=new DemoThread();
		DemoThread1 demoThread1=new DemoThread1();
		DemoThread2 demoThread2=new DemoThread2();
		DemoThread3 demoThread3=new DemoThread3();
		demoThread.start();
		demoThread1.start();
		demoThread2.start();
		demoThread3.start();
	}
}
class MyThreadDemo 
{
	MyThreadDemo()
	{
		System.out.println("My Thread Demo Of The Class");
	}
	//synchronized with a method
	static synchronized void showSample(int value)
	{
		for(int i=1;i<=10;i++)
		{
			System.out.println(Thread.currentThread().getName()+" : "+i*value);
			try
			{
				Thread.sleep(2000);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}	
}
class DemoThread extends Thread
{
	public void run()
	{
		MyThreadDemo.showSample(20);
	}
}
class DemoThread1 extends Thread
{
	public void run()
	{
		MyThreadDemo.showSample(2);
	}
}
class DemoThread2 extends Thread
{
	public void run()
	{
		MyThreadDemo.showSample(20);
	}
}
class DemoThread3 extends Thread
{
	public void run()
	{
		MyThreadDemo.showSample(2);
	}
}