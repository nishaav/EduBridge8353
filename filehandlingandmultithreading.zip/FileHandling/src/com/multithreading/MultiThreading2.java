package com.multithreading;

public class MultiThreading2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			MyThread1 mythread=new MyThread1();
			Thread t1=new Thread(mythread);
			t1.start();
			MultiThreadingAnonymous.methodWithAnonymous();
			MultiThreadingLambda.methodWithLambda();
		// anonymous
			//lambda
	}
}
//context switching : means switching from one thread to another to utilize the system efficiency
class MultiThreadingAnonymous {

	public static void methodWithAnonymous() {
		Runnable run=new Runnable() {//anonymous interface
			public void run() {
				for(int i=1;i<=5;i++) {
					Thread t1=Thread.currentThread();
					System.out.print(t1.getName());
					System.out.println(" i : "+i);

					try {
						Thread.sleep(300);
					}
					catch(Exception e) {
						e.printStackTrace();
					}
				}
			}
		};
		
		Thread t1=new Thread(run);
        t1.start();

	}

}
class MultiThreadingLambda {

	public static void methodWithLambda() {
		Runnable run=()->{
			for(int i=1;i<=5;i++) {
				Thread t1=Thread.currentThread();
				System.out.print(t1.getName());

				System.out.println(" i : "+i);
				try {
					Thread.sleep(300);
				}
				catch(Exception e) {
					e.printStackTrace();
				}
			}
		};
		
		Thread t1=new Thread(run);
        t1.start();
	}

}

class MyThread1 implements Runnable
{
	public void run()
	{
		for(int i=1;i<=5;i++)
		{
			Thread t1=Thread.currentThread();
			System.out.print(t1.getName());
			System.out.println(" i : "+i);
			try
			{
				Thread.sleep(2000);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
		}
}
