package com.multithreading;
//Deadlock
public class MultiThreading9 
{
	public static void main(String args[])
	{
		DemoThreadResource demo=new DemoThreadResource();
		demo.show();
	}
}
class DemoThreadResource
{
	void show()
	{
		final String r1="Resource1";
		final String r2="Resource2";
		
		Thread t1=new Thread() {
			public void run()
			{
				synchronized(r1)
				{
					System.out.println(Thread.currentThread().getName()+" : Occupied r1 resource");
					for(int i=1;i<=10;i++)
					{
						try
						{
							System.out.println(i);
							Thread.sleep(500);
						}
						catch(Exception e)
						{
							e.printStackTrace();
						}
					}
					synchronized(r2)
					{
						System.out.println(Thread.currentThread().getName()+" : Occupied r2 resource");
					}
				}
			}
		};
	
		
		
		Thread t2=new Thread() {
			public void run()
			{
				synchronized(r1)
				{
					System.out.println(Thread.currentThread().getName()+" : Occupied r2 resource");
					for(int i=1;i<=10;i++)
					{
						try
						{
							System.out.println(i);
							Thread.sleep(500);
						}
						catch(Exception e)
						{
							e.printStackTrace();
						}
					}
					synchronized(r2)
					{
						System.out.println(Thread.currentThread().getName()+" : Occupied r1 resource");
					}
				}
			}
		};
		
		t1.start();
		try
		{
			t1.join();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		t2.start();
	}
}