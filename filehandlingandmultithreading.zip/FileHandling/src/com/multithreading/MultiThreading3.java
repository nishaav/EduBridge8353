package com.multithreading;

public class MultiThreading3 
{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//JVM is working a single process and each java program is treated as a thread
		Thread t1=Thread.currentThread();
		System.out.println(t1.getId());
		System.out.println(t1.getName());
		System.out.println(t1.getPriority());
		System.out.println(t1.getState());
		System.out.println(t1.isAlive());
		System.out.println(t1.isDaemon());// used by garbage collector for garbage collection
		System.out.println(t1.isInterrupted());
		//ThreadScheduler is aligning the thread for execution
		System.out.println(Thread.MAX_PRIORITY);
		System.out.println(Thread.MIN_PRIORITY);
		System.out.println(Thread.NORM_PRIORITY);

		t1.setName("MultiThreading");
		System.out.println(t1.getName());
		
		
		
	}
}