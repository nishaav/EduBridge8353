package com.multithreading;

public class MultiThreading6 {

public static void main(String args[])
{
	DummyThread dummyThread=new DummyThread();
	ThreadClass1 tc1=new ThreadClass1(dummyThread);
	ThreadClass2 tc2=new ThreadClass2(dummyThread);
	tc1.start();
	tc2.start();
		
}
	
}
//Resource
class DummyThread 
{
	DummyThread()
	{
		System.out.println("Dummy Threaf Of The Class");
	}
	//synchronized with a method
	synchronized void showSample(int value)
	{
		for(int i=1;i<=10;i++)
		{
			System.out.println(Thread.currentThread().getName()+" : "+i*value);
			try
			{
				Thread.sleep(2000);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}	
}
//Thread 1
class ThreadClass1 extends Thread
{
	DummyThread dt;
	ThreadClass1(DummyThread dt)
	{
		this.dt=dt;
	}
	
	public void run()
	{
		dt.showSample(4);
	}
		
}
class ThreadClass2 extends Thread
{
	DummyThread dt;
	ThreadClass2(DummyThread dt)
	{
		this.dt=dt;
	}
	
	public void run()
	{
		dt.showSample(12);
	}
		
}