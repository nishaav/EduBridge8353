package com;

import java.io.FileWriter;

public class FileHandling2 {

	public static void main(String[] args) {
		// Working with Char Stream

		try
		{
			FileWriter fw=new FileWriter("C:\\Users\\hp\\OneDrive\\Desktop\\f1.txt");
			String str="Hii Learners to file handling demos";
			fw.write(str);
			fw.close();
			System.out.println("transfer successful");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
