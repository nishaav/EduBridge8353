package com;

import java.io.FileInputStream;
import java.io.SequenceInputStream;

public class FileHandling6 {

	public static void main(String[] args) 
	{
		try
		{
			FileInputStream fin1=new FileInputStream("C:\\Users\\hp\\OneDrive\\Desktop\\f1.txt");
			FileInputStream fin2=new FileInputStream("C:\\Users\\hp\\OneDrive\\Desktop\\f2.txt");
			SequenceInputStream sis=new SequenceInputStream(fin1, fin2);
			
			System.out.println(fin1.available());
			int i=0;
			String str="";
			while((i=sis.read())!=-1)
			{
				//System.out.print((char)i);
				str+=String.valueOf((char)i);
			}
			System.out.println(str);
			sis.close();
			fin2.close();
			fin1.close();
			
		}
		catch(Exception e)
		{
			
		}

	}

}
