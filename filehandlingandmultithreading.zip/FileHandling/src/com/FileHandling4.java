package com;

import java.io.FileInputStream;
import java.io.FileReader;

public class FileHandling4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			FileReader fin=new FileReader("C:\\Users\\hp\\OneDrive\\Desktop\\f1.txt");
			int i=0;
			while((i=fin.read())!=-1)
			{
				System.out.print((char)i);
			}
		}
		catch(Exception e)
		{
			// if file i not existing then we will get the exception, FileNotFoundException
			e.printStackTrace();
		}
	}

}
