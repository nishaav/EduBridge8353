package com;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;

public class FileHandling9 {

	public static void main(String[] args) {
		//BufferedOutputStream increases the speed of data transfer
		try
		{
			FileOutputStream fout=new FileOutputStream("C:\\Users\\hp\\OneDrive\\Desktop\\f1.txt");
			BufferedOutputStream bout=new BufferedOutputStream(fout);
			String str="Sample Data";
			byte b[]=str.getBytes();
			bout.write(b);
			bout.close();
			fout.close();
			System.out.println("Successful");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}

/* Sink Stream : Destination of data
 * 
 * 
 * Source Stream :  Source of data
 */
 