package com;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;

public class FileHandling5 {

	public static void main(String[] args) {
		try
		{
			//Writing data to multiple files in one go
			FileOutputStream fout1=new FileOutputStream("C:\\Users\\hp\\OneDrive\\Desktop\\f1.txt");//object for write
			FileOutputStream fout2=new FileOutputStream("C:\\Users\\hp\\OneDrive\\Desktop\\f2.txt");//object for write
			ByteArrayOutputStream bout=new ByteArrayOutputStream();
			String str="Demo Data";
			byte b[]=str.getBytes();
			bout.write(b);//to write the data to the stream
			bout.writeTo(fout1);//transfer the data to the file1
			bout.writeTo(fout2);//transfer the data to the file2
			bout.close();
			fout2.close();
			fout1.close();
			System.out.println("Successful");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}
