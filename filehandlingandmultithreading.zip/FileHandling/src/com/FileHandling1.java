package com;

import java.io.FileOutputStream;

public class FileHandling1 {

	public static void main(String[] args) {
		
		/*
		 *File Handling : the mechanism through which we will be able to read and write the data from and to the file.
		 * 
		 *Stream : Buffer which is used to transfer the data from one source to another.
		 *  
		 *
		 * 
		 * 2 types of streams which is used to transfer the data from source to destination
		 * 
		 * 1)Byte Stream
		 * 	conversion is performed explicitly(manually).
		 *  FileOutputStream
		 *  FileInputStream
		 *  ByteArrayOutputStream
		 *  BufferedOutputStream
		 * 2)Char Stream
		 *  conversion is performed implicitly(automatically/internally)
		 *  FileWriter
		 *  FileReader
		 *  CharArrayWriter
		 *  BufferedWriter
		 * 
		 *  
		 *  
		 *  package is : java.io
		 *  io: input-output
		 */
		
		try
		{
//			FileOutputStream fout=new FileOutputStream("C:\\Users\\hp\\OneDrive\\Desktop\\f1.txt"); object for write operation
			FileOutputStream fout=new FileOutputStream("C:\\Users\\hp\\OneDrive\\Desktop\\f1.txt",true);//object for write with append mode operation
			// in case the file is not existing at the specified destination.
			String str=" for final assessment";
			byte b[]=str.getBytes();
			fout.write(b);
			fout.close();
			System.out.println("Successfully transferred the data!!");
		}
		catch(Exception e)
		{
			System.out.println("Exception : "+e);
		}
		
		
		
		
		
		
		 
		 

	}

}
