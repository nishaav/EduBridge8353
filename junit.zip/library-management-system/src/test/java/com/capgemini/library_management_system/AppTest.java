package com.capgemini.library_management_system;

import  org.junit.*;
import org.junit.Test;
import static org.junit.Assert.*;//static pathing or static import statement

/**
 * Unit test for simple App.
 */
public class AppTest //test case class
{
	App app;
// before the execution of all the testcases
	@BeforeClass
	public static void startOfProgram()
	{
		System.out.println("STARTING OF TEST CASE EXECUTION");
	}

	//method annotated with @Before annotation is called before the execution of each test case
	@Before
	public void createInstance()
	{
		System.out.println("Before Each Test Case");
		app=new App();
	}
    /**
     * Rigorous Test :-)
     * @Test annotation tells that the specified method of public void type is created 
     * as a test case which the system needs to execute
     */
    @Test
    public void getYoungerValue()//test case method
    {
    	int age=app.getYoungerAge(34,56,22);
    	//assertEquals(" "+22+" ", " "+age+" ");
    	assertEquals("Invalid output getting generated"," "+22+" ", " "+age+" ");
    }
    @Test 
    public void testIsEven()
    {
    	assertTrue(app.isEven(34));
    }
   
    @AfterClass
	public static void endOfProgram()
	{
		System.out.println("END OF PROGRAM");
	}

	//method annotated with @Before annotation is called before the execution of each test case
	@After
	public void destroyInstance()
	{
		System.out.println("AFter Each test case");
		app=null;
	}    
}
//methods annotated with BeforeClass and AfterClass must be static
/*

BeforeClass->BeforeAll
AfterClass->AfterAll
Before->BeforeEach
After->AfterEach

*/