package com.capgemini.library_management_system;
public class App //tested class
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
    
    
    public int getYoungerAge(int num1,int num2,int num3)//tested method
    {
    	if((num1<num2) && (num1<num3))
    	{
    		return num1;
    	}
    	else if(num2<num3)
    	{
    		return num2;	
    	}
    	else
    	{
    		return num3;
    	}
    	
    }
    public boolean isEven(int num1)
    {
    	if(num1%2==0)
    	{
    		return true;
    	}
    	else
    	{
    		return false;
    	}
    }
}