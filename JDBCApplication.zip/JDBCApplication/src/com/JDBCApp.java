package com;

import java.sql.*;

public class JDBCApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
 * JDBC 5 steps : 
 * 1)Register the driver
 * 2)Create the connection
 * 3)Prepare the query
 * 4)Execute the query
 * 5)Close the connection
 * 
 * 
 */
		try
		{
			//1
			Class.forName("com.mysql.cj.jdbc.Driver");
			//2
			//https://www. 3306/3307/3308/3309
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/batch2?autoReconnect=true&useSSL=false","root","root");
			//3
			//PreparedStatement : insert/update/delete query
			String query="DELETE FROM learner_batch_2_info WHERE learner_id=9";
			PreparedStatement ps=con.prepareStatement(query);
			//4 
			int count=ps.executeUpdate();
			if(count>0)
			{
				System.out.println("Data deleted successfully");
			}
			else
			{
				System.out.println("Unable to delete data");
			}
			//5
			ps.close();
			con.close();
		}
		catch(Exception e)
		{
			System.out.println("Exception caught");
			e.printStackTrace();
		}
	}

}
