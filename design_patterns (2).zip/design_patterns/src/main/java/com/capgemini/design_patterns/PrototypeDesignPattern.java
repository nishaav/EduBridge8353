package com.capgemini.design_patterns;

/*
 * Prototype Design Pattern :
 * cloning of the existing object rather than creating a new one.
 * 
 * Advantage :
 * 1)the client gets the new object without knowing the details about the type of object.
 * 2)reduces need to sub-classing
 * 3)you can create or remove the object at runtime.
 * 4) hides the complexities of object creation as well.
 * 
 * 
 */
public class PrototypeDesignPattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentRecord studentRecord=new StudentRecord(1,"Jatin","C-1,Janakpuri,New Delhi-110059");
		studentRecord.show();
		StudentRecord studentRecord1=(StudentRecord) studentRecord.getClone();//downcasting
		//converting the instance of parent type into child class type reference.
		studentRecord1.show();
		StudentRecord studentRecord2=(StudentRecord) studentRecord.getClone();//downcasting
		//converting the instance of parent type into child class type reference.
		studentRecord2.show();

		StudentRecord studentRecord3=(StudentRecord) studentRecord.getClone();//downcasting
		//converting the instance of parent type into child class type reference.
		studentRecord3.show();

		StudentRecord studentRecord4=(StudentRecord) studentRecord.getClone();//downcasting
		//converting the instance of parent type into child class type reference.
		studentRecord4.show();

	}
}

interface Prototype
{
	public Prototype getClone();
}
//Prototype p=new StudentRecord();//upcasted object
//coverting the instance of parent type into child class
class StudentRecord implements Prototype
{
	private int id;
	private String name;
	private String address;
	
	StudentRecord()
	{
		System.out.println("Student Record");
		System.out.println("Id \t Name \t Address");
	}
	
	StudentRecord(int id,String name,String address)
	{
		this();
		this.id=id;
		this.name=name;
		this.address=address;
	}

	public void show()
	{
		System.out.println(id+"\t"+name+"\t"+address);
	}
	
	public Prototype getClone()
	{
		return new StudentRecord(id,name,address);
	}
}