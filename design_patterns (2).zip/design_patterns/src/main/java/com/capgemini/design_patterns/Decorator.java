package com.capgemini.design_patterns;

public class Decorator 
{
	public static void main(String args[])
	{
		Shape sh=new Rectangle();
		Shape sh1=new Triangle();
		sh.show();
		sh1.show();
		Shape sh2=new SmallRectangleDecorator(sh);
		sh2.show();
		Shape sh3=new SmallRectangleDecorator(sh1);
		sh3.show();
	}
}
interface Shape
{
	void show();//public abstract
}
class Rectangle implements Shape
{
	public void show()
	{
		System.out.println("Shape is Rectangle");	
	}
}
class Triangle implements Shape
{
	public void show()
	{
		System.out.println("Shape is Triangle");	
	}
}
abstract class ShapeDecorator implements Shape
{
	Shape shape;
	
	ShapeDecorator(Shape shape)
	{
		this.shape=shape;
	}
	
	public void show()
	{
		shape.show();
	}
}
class SmallRectangleDecorator extends ShapeDecorator
{

	SmallRectangleDecorator(Shape shape) {
		super(shape);
		// TODO Auto-generated constructor stub
	}
	
	public void show()
	{
		shape.show();
		setColor(shape);
	}

	private void setColor(Shape shape)
	{
		System.out.println("Color: As per requirement");
	}
}
/*
 * Decorator Design Pattern :
 * 1) is useful to form a larger structure without modifying the original class
 * 2)it makes the application more flexible to achieve the desired functionality by adding an object.
   3)applicable in variety of java IO classes like we FileReader,BufferedReader, BufferedWriter, File class	 

* Steps :
* 1) Create an interface
* 2) create a class that implements the created interface
* 3) create an abstract decorator class implements the same interface
* 4) create a decorator class extending the above abstract decorator class
* 5) use the decorator class created above to decorate interface objects.//main
* 6) verify the code
*/

