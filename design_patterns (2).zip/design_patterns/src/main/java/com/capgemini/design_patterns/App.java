package com.capgemini.design_patterns;

/**
 * Hello world!
 *
 *Singleton design pattern : design a class that has only 1 object and provides a global
 *access.
 *
 *benefit : save the memory and not creating multiple objects at each request rather
 *single object will be reused.
 *
 *SPRING framework by default creates a singleton object.
 *
 *private constructor : will not allow to access the constructor outside the class.
 *static member : it occupies memory only once
 *static factory method : method should return the object of the class.
 */
public class App 
{
    public static void main( String[] args )
    {
    	Student student=Student.getStudentObject();
    	student.getCourseInfo();
    	Student student1=Student.getStudentObject();
    	student1.getCourseInfo();
    	Student student2=Student.getStudentObject();
    	student2.getCourseInfo();
    	Student student3=Student.getStudentObject();
    	student3.getCourseInfo();
    	Student student4=Student.getStudentObject();
    	student4.getCourseInfo();
    }
}
