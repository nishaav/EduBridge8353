package com;
import java.util.Scanner;
public class Main {
public static void main(String[] args) {
// Why String is immutable?
	
	String str="Java";//String literal String constant pool
	String string=new String("Java");//String instance or object heap area
	
	//String is immutable
	
	String data="Java";
	String string2=new String("Java");

	
	
	// == : comparison
	// String it compares the references i.e. the address
	//comparing the values
	// equals
	// equalsIgnoreCase
	// compare
			
	if(str==data)
	{
		System.out.println("Matches");
	}
	else
	{
		System.out.println("Not Found");
	}


	if(string==string2)
	{
		System.out.println("Matches");
	}
	else
	{
		System.out.println("Not Found");
	}

}
}


//public class Main {
//	public static void main(String[] args) {
//		Scanner sc = new Scanner(System.in);
//		System.out.println("Enter the number of  row :");
//		int n = sc.nextInt();
//        System.out.println("Enter the number of  column :");
//		int m = sc.nextInt();
//		int array[][] = new int [n][m];
//		System.out.println("Enter the elements of array :");
//		for(int i=0;i<n;i++) {
//			for(int j=0;j<m;j++) {
//			array[i][j] = sc.nextInt();
//		}
//		}
//		int max = array[0][0];
//		for(int i =0;i<n;i++) {
//			for(int j=0;j<m;j++) {
//			if(max<array[i][j]) {
//				max = array[i][j];
//			}
//			}
//		}
//		System.out.println("Maximum value in the array is : " + max);
//	}
//	}



//public class Main
//{
//	public static void main(String[] args) {
//	    Scanner scanner = new Scanner (System.in);
//
//	    System.out.println("Provide the inputs for row and column");
//	    int rows = scanner.nextInt();
//	    int cols = scanner.nextInt();
//		
//		int [][] mat = new int [rows][cols];
//		
//		for(int row = 0; row<rows; row++){
//		    for(int col = 0; col < cols; col++){
//		        mat[row][col] = scanner.nextInt();
//		    }
//		}
//		/*
//		 * 
//		 *  23 45 67
//		 *  56 34 12
//		 *  58 75 31
//		 * 
//		 */
//		int max = mat[0][0];
//		for(int row = 0; row<rows; row++){
//		    for(int col = 0; col < cols; col++){
//		        if(max < mat[row][col]){
//		            max = mat[row][col];
//		        }
//		    }
//		}
//		System.out.println(max+" ");
//		
//	}
//}
