package com;

import java.util.Arrays;

public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str="EDUBRIDGE";
		char ch[]=str.toCharArray();//method of String class that converts the string into an array of char type
		//starting from 0 index till the last character of the String
		//0 4
		char ch1[]=new char[4];
		//3 to 6
		//3,8
		//3 to 7->3,4,5,6,7
		str.getChars(3, 7, ch1, 0);
		//getChars method of String class that converts the string into an array of char type
		//starting from specified index till the last index specified
		for(int i=0;i<ch1.length;i++)
		{
			System.out.println(ch1[i]);
		}
		System.out.println(Arrays.toString(ch1));
		Learner learner=new Learner();
		learner.show();
	}

}
class Learner
{
	void show()
	{
		System.out.println("Hello World");
	}
}
