package com;

import java.util.Arrays;

public class Main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str1="Java Program ";
String str2="Programming";
String str3=str1+str2;//+ for concatenation
String str4=str1.concat(str2);// concat method for concatenation

System.out.println(str3);


System.out.println(str4);
int length=str4.length();
//System.out.println(str4.length());
	System.out.println(length);
	

	
char ch[]=new char[8];
str1.getChars(0, 8, ch, 0);

System.out.println(Arrays.toString(ch));
System.out.println("["+ch[4]+"]");

char ch1[]=str1.toCharArray();
System.out.println(Arrays.toString(ch1));


System.out.println(str1.compareToIgnoreCase("Java"));
System.out.println(str1.compareTo("Java"));
System.out.println(str1.isEmpty());
System.out.println(str1.isBlank());
String s="";
System.out.println(s.isEmpty());
System.out.println(s.isBlank());

s=" ";
System.out.println(s.isEmpty());
System.out.println(s.isBlank());

String value1="J";
String value2="j";
//printing the ASCII code
System.out.println((int)value1.charAt(0));
System.out.println((int)value2.charAt(0));

System.out.println(value1.compareTo(value2));//74-106=>-32

System.out.println(value2.compareTo(value1));//106-74=>32

System.out.println(value1.compareToIgnoreCase(value2));

System.out.println(value2.compareToIgnoreCase(value1));







	}
}
